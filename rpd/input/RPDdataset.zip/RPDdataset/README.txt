ground truth: imagename_gx_gy.jpg/png
